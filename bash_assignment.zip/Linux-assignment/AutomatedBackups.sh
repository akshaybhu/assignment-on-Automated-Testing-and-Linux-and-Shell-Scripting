#!/bin/bash

source="home/user/documents"
backup="home/user/backup"
backupFile="documents_backup.tar.gz"

# To verify the source/backup directory exists
if [ -d $source ]; then
    if [ ! -d $backup ]; then
        mkdir -p "$backup"
    fi
fi

# Compress the documents directory into a tarball\
tar -czf "$backup/$backupFile" -C "$source" .

echo "Backup created with filename/path '$backup/$backupFile'."

echo " For automated backups using cron, type 'crontab -e' and will open editor"
echo " enter --> 0 <timeofthedaytorun> * * * /path/to/script , save and close the editor"
