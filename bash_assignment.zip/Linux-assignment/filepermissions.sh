#!/bin/bash

# Check if the file name is provided
if [ ! -z "$1" ]; then
		fileName="$1"
fi

# Check if the file exists
if [ ! -e "$fileName" ]; then
        echo "Error: $fileName does not exist."
        exit 1
fi

# Check for read permission
if [ -r "$fileName" ]; then
        echo "Read permission: available"
else
        echo "Read permission: not available"
fi

# Check for write permission
if [ -w "$fileName" ]; then
        echo "Write permission: available"
else
        echo "Write permission: not available"
fi

# Check for execute permission
if [ -x "$fileName" ]; then
        echo "Execute permission: available"
else
        echo "Execute permission: not available"
fi
