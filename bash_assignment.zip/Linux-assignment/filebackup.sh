#!/bin/bash

if [ ! -z "$1" ]; then   # To check if the argument is not empty
    if [ -d "$1" ]; then # To check if the argument provided directory exists
        echo "Argument is good to use as a directory for backup"
    fi
fi

timestamp=$(date +"%Y%m%d_%H%M%S")

# Create backup directory if doesn't exist.
if [ ! -d "backup_$timestamp" ]; then
    mkdir -p "backup_$timestamp";
    cp "$1"/*.txt "backup_$timestamp"
fi

echo "Backup of all txt files completed"