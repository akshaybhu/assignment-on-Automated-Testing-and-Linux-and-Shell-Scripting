#!/bin/bash

PROCESS="apache2"  # example taken for apache2 process.

logFile="/var/log/apache2_monitor.log"

# Check if the process is running
if ! pgrep -x "$PROCESS" > /dev/null; then
    # Start the process
    systemctl start "$PROCESS"
    # Log the action
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $PROCESS has been started." >> "$logFile"
else
    echo "$PROCESS is running."
fi