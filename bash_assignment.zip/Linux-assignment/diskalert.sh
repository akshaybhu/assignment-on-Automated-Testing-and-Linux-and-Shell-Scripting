#!/bin/bash

THRESHOLD=80 # Set the threshold percentage

Disk_usage=$(df / | grep / | awk '{ print $5 }' | sed 's/%//g') # Get the current disk usage of the root.
# df - checks disk usage
# grep - to filter the output
# awk - to extract
# sed - to remove % sign from output

# Check if the usage exceeds the threshold
if [ "$Disk_usage" -gt "$THRESHOLD" ]; then
        subject="Disk Usage Alert: ${Disk_usage}%"
        message="The root filesystem usage is at ${Disk_usage}%"                      
		echo "$message" | mail -s "$subject" "system@admin.com"
        echo "Alert email sent to system@admin.com"
else
        echo "Disk usage is under control: ${Disk_usage}%."
fi