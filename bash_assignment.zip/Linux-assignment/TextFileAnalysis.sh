#!/bin/bash

# Check if a file argument is provided
if [ ! -z "$1" ]; then
    if [ -f "$1" ]; then
        if [[ "$1" == *.txt ]]; then
            # Count lines, words, and characters
            Numberoflines=$(wc -l < "$1")
            Numberofwords=$(wc -w < "$1")
            Numberofcharacters=$(wc -m < "$1")

            # Display the counts
            echo "Lines: $Numberoflines"
            echo "Words: $Numberofwords"
            echo "Characters: $Numberofcharacters"
        else
            echo "File not found or not a .txt file!"
            exit 1
        fi
    fi    
fi  



