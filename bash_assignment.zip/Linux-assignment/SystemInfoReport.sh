#!/bin/bash

# Assigning the output file
output_file="system_report.txt"

# Add a header to the report
echo "System Information Report" > "$output_file"
echo "----------------------------------------" >> "$output_file"

# Get system uptime
echo "System Uptime:" >> "$output_file"
uptime >> "$output_file"
echo "----------------------------------------" >> "$output_file"

# Get memory usage
echo "Memory Usage:" >> "$output_file"
vm_stat | awk 'NR' >> "$output_file"
echo "----------------------------------------" >> "$output_file"

# Get CPU load
echo "CPU Load:" >> "$output_file"
top -l 1 | grep "CPU usage" >> "$output_file"
echo "----------------------------------------" >> "$output_file"

# Get disk usage
echo "Disk Usage:" >> "$output_file"
df -h >> "$output_file"
echo "----------------------------------------" >> "$output_file"

# Get running processes
echo "Running Processes:" >> "$output_file"
ps aux | head -n 5 >> "$output_file"
echo "----------------------------------------" >> "$output_file"

echo "System information report generated and saved to $output_file"
