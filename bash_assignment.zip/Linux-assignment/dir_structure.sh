#!/bin/bash

# Define the base directory
BASE_DIR="home/user"

# Create the base directory if it doesn't exist
if [ ! -d home/user ]; then
    mkdir -p "$BASE_DIR";
fi

# Create the 'projects' directory and its sub directories.
if [ ! -d home/projects ]; then
    mkdir -p "$BASE_DIR/projects/project1";  
    mkdir -p "$BASE_DIR/projects/project2"; 
    mkdir -p "$BASE_DIR/projects/project3";  
fi

# Create the 'documents' directory
if [ ! -d home/documents ]; then
    mkdir -p "$BASE_DIR/documents"; 
fi

# Create the 'downloads' directory
if [ ! -d home/downloads ]; then
    mkdir -p "$BASE_DIR/downloads";  
fi

echo "Directory structure is ready"
